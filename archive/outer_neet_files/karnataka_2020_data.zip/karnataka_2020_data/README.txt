Karnataka UG NEET 2020 – Data Collection Summary
-----------------------------------------------

This directory summarizes the official documents available on the Karnataka Examinations Authority (KEA) website for UG NEET 2020 admissions.  The KEA site provides numerous PDFs covering cutoff ranks, seat matrices, fee schedules, mop‑up rounds and special instructions.  Round‑1 and round‑2 allotment results were not available as static PDFs; therefore, closing‑rank documents serve as the primary source of rank data.

Key document categories:

1. First‑round cutoff PDFs (closing ranks)
   * `medi_cutoff_gen_r1.pdf` – general quota cutoff ranks for round 1.
   * `medi_cutoff_hk_r1.pdf` – Hyderabad‑Karnataka (HK) quota cutoff ranks for round 1.
   * `medi_cutoff_priv_r1.pdf` – Private, NRI and Others (P/N/Q) quota cutoff ranks for round 1.

2. First‑round seat‑matrix PDFs
   * `medical_g.pdf` – government general‑quota seat matrix (21‑Nov‑2020).
   * `medical_g_hk.pdf` – HYD‑KAR quota seat matrix.
   * `medical_g_spl.pdf` – special‑category seat matrix.
   * `medical_p.pdf` – private‑quota seat matrix with categories (GMP, minority categories, etc.) and a note that non‑Karnataka candidates are only eligible for open quota.
   * `medical_n.pdf` – NRI/OCI/PIO seat matrix.
   * `medical_q.pdf` – ‘Other (Q)’ quota seat matrix.
   * `fees.pdf` – government, private, NRI and Other fees for each college.

3. Second‑round cutoff PDFs (closing ranks)
   * `medi_cutoff_gen.pdf` – general quota second‑round cutoff.
   * `medi_cutoff_hk.pdf` – HYD‑KAR second‑round cutoff.
   * `medi_cutoff_priv.pdf` – P/N/Q second‑round cutoff.

4. Seat matrices for returned seats (ESIC and AIQ)
   * `medical_g_esi.pdf`, `medical_g_hk_esi.pdf`, `medical_g_spl_esi.pdf` – seat matrices for seats returned from ESIC quota.
   * Additional seat matrices for seats returned from All‑India quota (AIQ) exist but were not all downloaded.

5. Mop‑up round documents
   * `medical_g_stg2.pdf`, `medical_p_stg2.pdf`, `medical_q_stg2.pdf` – stage‑2 seat matrices for mop‑up round.
   * `medical_g_stg3.pdf`, `medical_p_stg3.pdf`, `medical_q_stg3.pdf` – stage‑3 seat matrices (remaining seats after stage 2).
   * `medical_g_mopup2.pdf`, `medical_p_mopup2.pdf`, `medical_q_mopup2.pdf` – dental mop‑up seat matrices (after 07‑Jan‑2021).
   * `fees_dental.pdf` – dental college fee structure (G, P, NRI and Other).
   * `medical_mopup_close.pdf` – unallocated seats after mop‑up round.
   * `r3_seats_dental.pdf` – list of dental candidates whose seats were cancelled and re‑added to the seat matrix.
   * Mop‑up schedules, flow charts and additional instructions were present but scanned and not parsed.

6. Brochure and special instructions
   * `ebrochure.pdf` – e‑information bulletin (instructions, eligibility, calendar of events, seat classification, etc.); notes that rural service bond format and St John’s/ESIC bond conditions are hosted on the KEA site.
   * `sjmc.pdf` – St John’s Medical College MBBS admission bulletin (seat matrix for 150 seats across Roman‑Catholic categories and a two‑year rural‑service bond requirement).
   * `aiq_joined_kea_candidateskannada.pdf` – list of candidates admitted through All‑India quota whose seats were cancelled in KEA rounds.

To acquire the raw PDFs, access the KEA site (https://cetonline.karnataka.gov.in/kea/ugneet2020) and look for the above file names; some are under the `R1/`, `R2/` or `R3/` directories of the `keawebentry456/ugneet2020` path.  Use the PDF URLs with the official domain (e.g., `https://cetonline.karnataka.gov.in/keawebentry456/ugneet2020/R1/medical_g.pdf`).

This directory contains only this summary; the PDFs themselves have not been downloaded.
